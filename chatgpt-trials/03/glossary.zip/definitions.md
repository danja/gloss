#### Ablex 
 `Refined definition of Ablex.`

#### Alpha 
 `Refined definition of Alpha.`

#### Annals 
 `Refined definition of Annals.`

#### Another 
 `Refined definition of Another.`

#### Answ 
 `Refined definition of Answ.`

#### Applica 
 `Refined definition of Applica.`

#### Applications 
 `Refined definition of Applications.`

#### Approac 
 `Refined definition of Approac.`

#### April 
 `Refined definition of April.`

#### Arti 
 `Refined definition of Arti.`

#### Aw 
 `Refined definition of Aw.`

#### Axioms 
 `Refined definition of Axioms.`

#### Based 
 `Refined definition of Based.`

#### Basis 
 `Refined definition of Basis.`

#### Bey 
 `Refined definition of Bey.`

#### Blac 
 `Refined definition of Blac.`

#### Bruce 
 `Refined definition of Bruce.`

#### Buc 
 `Refined definition of Buc.`

#### Cameron 
 `Refined definition of Cameron.`

#### Carnegie 
 `Refined definition of Carnegie.`

#### Case 
 `Refined definition of Case.`

#### Cen 
 `Refined definition of Cen.`

#### Circumscription 
 `Refined definition of Circumscription.`

#### Clearly 
 `Refined definition of Clearly.`

#### Colors 
 `Refined definition of Colors.`

#### Com 
 `Refined definition of Com.`

#### Common 
 `Refined definition of Common.`

#### Computer 
 `Refined definition of Computer.`

#### Computing 
 `Refined definition of Computing.`

#### Con 
 `Refined definition of Con.`

#### Concepts 
 `Refined definition of Concepts.`

#### Confer 
 `Refined definition of Confer.`

#### Consequen 
 `Refined definition of Consequen.`

#### Consider 
 `Refined definition of Consider.`

#### Consultation 
 `Refined definition of Consultation.`

#### Cultur 
 `Refined definition of Cultur.`

#### D 
 `Refined definition of D.`

#### Da 
 `Refined definition of Da.`

#### De 
 `Refined definition of De.`

#### Dec 
 `Refined definition of Dec.`

#### Default 
 `Refined definition of Default.`

#### Departmen 
 `Refined definition of Departmen.`

#### Description 
 `Refined definition of Description.`

#### Dis 
 `Refined definition of Dis.`

#### Donald 
 `Refined definition of Donald.`

#### Dunham 
 `Refined definition of Dunham.`

#### Eac 
 `Refined definition of Eac.`

#### Edin 
 `Refined definition of Edin.`

#### Edw 
 `Refined definition of Edw.`

#### Ellis 
 `Refined definition of Ellis.`

#### Elmford 
 `Refined definition of Elmford.`

#### Ernst 
 `Refined definition of Ernst.`

#### Esp 
 `Refined definition of Esp.`

#### Ev 
 `Refined definition of Ev.`

#### Exp 
 `Refined definition of Exp.`

#### Fik 
 `Refined definition of Fik.`

#### First 
 `Refined definition of First.`

#### G 
 `Refined definition of G.`

#### Gener 
 `Refined definition of Gener.`

#### General 
 `Refined definition of General.`

#### Generalit 
 `Refined definition of Generalit.`

#### George 
 `Refined definition of George.`

#### Ginsb 
 `Refined definition of Ginsb.`

#### Green 
 `Refined definition of Green.`

#### Ha 
 `Refined definition of Ha.`

#### Hall 
 `Refined definition of Hall.`

#### Harv 
 `Refined definition of Harv.`

#### Heinz 
 `Refined definition of Heinz.`

#### Herb 
 `Refined definition of Herb.`

#### Here 
 `Refined definition of Here.`

#### Heuristic 
 `Refined definition of Heuristic.`

#### Holmes 
 `Refined definition of Holmes.`

#### Horn 
 `Refined definition of Horn.`

#### Horw 
 `Refined definition of Horw.`

#### Human 
 `Refined definition of Human.`

#### Ideas 
 `Refined definition of Ideas.`

#### Imp 
 `Refined definition of Imp.`

#### Implicit 
 `Refined definition of Implicit.`

#### Individual 
 `Refined definition of Individual.`

#### Institute 
 `Refined definition of Institute.`

#### International 
 `Refined definition of International.`

#### Jan 
 `Refined definition of Jan.`

#### Joint 
 `Refined definition of Joint.`

#### Journal 
 `Refined definition of Journal.`

#### July 
 `Refined definition of July.`

#### Kauf 
 `Refined definition of Kauf.`

#### Kaufmann 
 `Refined definition of Kaufmann.`

#### Kno 
 `Refined definition of Kno.`

#### L 
 `Refined definition of L.`

#### Laird 
 `Refined definition of Laird.`

#### Learning 
 `Refined definition of Learning.`

#### Lecture 
 `Refined definition of Lecture.`

#### Lifsc 
 `Refined definition of Lifsc.`

#### Lo 
 `Refined definition of Lo.`

#### Logic 
 `Refined definition of Logic.`

#### London 
 `Refined definition of London.`

#### Ma 
 `Refined definition of Ma.`

#### Mac 
 `Refined definition of Mac.`

#### Machine 
 `Refined definition of Machine.`

#### Main 
 `Refined definition of Main.`

#### Me 
 `Refined definition of Me.`

#### Meltzer 
 `Refined definition of Meltzer.`

#### Mic 
 `Refined definition of Mic.`

#### Mo 
 `Refined definition of Mo.`

#### Moreo 
 `Refined definition of Moreo.`

#### Morgan 
 `Refined definition of Morgan.`

#### My 
 `Refined definition of My.`

#### N 
 `Refined definition of N.`

#### Namely 
 `Refined definition of Namely.`

#### Need 
 `Refined definition of Need.`

#### Next 
 `Refined definition of Next.`

#### Nils 
 `Refined definition of Nils.`

#### Nilsson 
 `Refined definition of Nilsson.`

#### No- 
 `Refined definition of No-.`

#### Non- 
 `Refined definition of Non-.`

#### North 
 `Refined definition of North.`

#### Notice 
 `Refined definition of Notice.`

#### O 
 `Refined definition of O.`

#### Ob 
 `Refined definition of Ob.`

#### Once 
 `Refined definition of Once.`

#### Order 
 `Refined definition of Order.`

#### Philosophical 
 `Refined definition of Philosophical.`

#### Pren 
 `Refined definition of Pren.`

#### Press 
 `Refined definition of Press.`

#### Pro 
 `Refined definition of Pro.`

#### Problem 
 `Refined definition of Problem.`

#### Problems 
 `Refined definition of Problems.`

#### Program 
 `Refined definition of Program.`

#### Programs 
 `Refined definition of Programs.`

#### Prop 
 `Refined definition of Prop.`

#### Q 
 `Refined definition of Q.`

#### Quali 
 `Refined definition of Quali.`

#### Question 
 `Refined definition of Question.`

#### Ra 
 `Refined definition of Ra.`

#### Randall 
 `Refined definition of Randall.`

#### Rea 
 `Refined definition of Rea.`

#### Readings 
 `Refined definition of Readings.`

#### References 
 `Refined definition of References.`

#### Reiter 
 `Refined definition of Reiter.`

#### Represen 
 `Refined definition of Represen.`

#### Resolution 
 `Refined definition of Resolution.`

#### Result- 
 `Refined definition of Result-.`

#### Rosen 
 `Refined definition of Rosen.`

#### Rules 
 `Refined definition of Rules.`

#### S 
 `Refined definition of S.`

#### Science 
 `Refined definition of Science.`

#### Sciences 
 `Refined definition of Sciences.`

#### Scienti 
 `Refined definition of Scienti.`

#### Self-Or 
 `Refined definition of Self-Or.`

#### Sense 
 `Refined definition of Sense.`

#### Sha 
 `Refined definition of Sha.`

#### Sherlo 
 `Refined definition of Sherlo.`

#### Shortli 
 `Refined definition of Shortli.`

#### Solv 
 `Refined definition of Solv.`

#### Someho 
 `Refined definition of Someho.`

#### Standp 
 `Refined definition of Standp.`

#### Stanfor 
 `Refined definition of Stanfor.`

#### Stanford 
 `Refined definition of Stanford.`

#### Stationery 
 `Refined definition of Stationery.`

#### Study 
 `Refined definition of Study.`

#### Supp 
 `Refined definition of Supp.`

#### System 
 `Refined definition of System.`

#### Systems 
 `Refined definition of Systems.`

#### Th 
 `Refined definition of Th.`

#### Theorem 
 `Refined definition of Theorem.`

#### Theorem- 
 `Refined definition of Theorem-.`

#### Theories 
 `Refined definition of Theories.`

#### Thes 
 `Refined definition of Thes.`

#### Thought 
 `Refined definition of Thought.`

#### Tioga 
 `Refined definition of Tioga.`

#### Un 
 `Refined definition of Un.`

#### Unfortunately 
 `Refined definition of Unfortunately.`

#### Univ 
 `Refined definition of Univ.`

#### Unless 
 `Refined definition of Unless.`

#### Vladimir 
 `Refined definition of Vladimir.`

#### Whenev 
 `Refined definition of Whenev.`

#### While 
 `Refined definition of While.`

#### Within 
 `Refined definition of Within.`

#### Without 
 `Refined definition of Without.`

#### Zermelo-F 
 `Refined definition of Zermelo-F.`

#### a-natur 
 `Refined definition of a-natur.`

#### logic-based 
 `Refined definition of logic-based.`

#### no-one 
 `Refined definition of no-one.`

#### pattern-action 
 `Refined definition of pattern-action.`

#### rst-order 
 `Refined definition of rst-order.`

#### ule-b 
 `Refined definition of ule-b.`

#### www-formal 
 `Refined definition of www-formal.`

