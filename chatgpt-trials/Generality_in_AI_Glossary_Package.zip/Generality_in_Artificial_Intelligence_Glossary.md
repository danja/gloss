## Generality in Artificial Intelligence Glossary

#### /@steam.stanford.edu:/u/ftp/jmc/generality.tex:
```
This is a placeholder definition for the term '/@steam.stanford.edu:/u/ftp/jmc/generality.tex:'.

```

#### 1950s
```
This is a placeholder definition for the term '1950s'.

```

#### 1960s
```
This is a placeholder definition for the term '1960s'.

```

#### 1970s
```
This is a placeholder definition for the term '1970s'.

```

#### abbreviation
```
This is a placeholder definition for the term 'abbreviation'.

```

#### abnormal
```
This is a placeholder definition for the term 'abnormal'.

```

#### about
```
This is a placeholder definition for the term 'about'.

```

#### absence
```
This is a placeholder definition for the term 'absence'.

```

#### abstraction
```
This is a placeholder definition for the term 'abstraction'.

```

#### accepted
```
This is a placeholder definition for the term 'accepted'.

```

#### accepting
```
This is a placeholder definition for the term 'accepting'.

```

#### accomplished
```
This is a placeholder definition for the term 'accomplished'.

```

#### according
```
This is a placeholder definition for the term 'according'.

```

#### account
```
This is a placeholder definition for the term 'account'.

```

#### achieve
```
This is a placeholder definition for the term 'achieve'.

```

#### achieved
```
This is a placeholder definition for the term 'achieved'.

```

#### achieving
```
This is a placeholder definition for the term 'achieving'.

```

#### action
```
This is a placeholder definition for the term 'action'.

```

#### actions
```
This is a placeholder definition for the term 'actions'.

```

#### activity
```
This is a placeholder definition for the term 'activity'.

```

#### added
```
This is a placeholder definition for the term 'added'.

```

#### addition
```
This is a placeholder definition for the term 'addition'.

```

#### additional
```
This is a placeholder definition for the term 'additional'.

```

#### advantage
```
This is a placeholder definition for the term 'advantage'.

```

#### advantageous
```
This is a placeholder definition for the term 'advantageous'.

```

#### advantages
```
This is a placeholder definition for the term 'advantages'.

```

#### after
```
This is a placeholder definition for the term 'after'.

```

#### again
```
This is a placeholder definition for the term 'again'.

```

#### against
```
This is a placeholder definition for the term 'against'.

```

#### allow
```
This is a placeholder definition for the term 'allow'.

```

#### allowed
```
This is a placeholder definition for the term 'allowed'.

```

#### allowing
```
This is a placeholder definition for the term 'allowing'.

```

#### allows
```
This is a placeholder definition for the term 'allows'.

```

#### almost
```
This is a placeholder definition for the term 'almost'.

```

#### already
```
This is a placeholder definition for the term 'already'.

```

#### also
```
This is a placeholder definition for the term 'also'.

```

#### although
```
This is a placeholder definition for the term 'although'.

```

#### always
```
This is a placeholder definition for the term 'always'.

```

#### analogous
```
This is a placeholder definition for the term 'analogous'.

```

#### analogy
```
This is a placeholder definition for the term 'analogy'.

```

#### another
```
This is a placeholder definition for the term 'another'.

```

#### apect1
```
This is a placeholder definition for the term 'apect1'.

```

#### appears
```
This is a placeholder definition for the term 'appears'.

```

#### applicability
```
This is a placeholder definition for the term 'applicability'.

```

#### applied
```
This is a placeholder definition for the term 'applied'.

```

#### applies
```
This is a placeholder definition for the term 'applies'.

```

#### apply
```
This is a placeholder definition for the term 'apply'.

```

#### approach
```
This is a placeholder definition for the term 'approach'.

```

#### approaches
```
This is a placeholder definition for the term 'approaches'.

```

#### appropriate
```
This is a placeholder definition for the term 'appropriate'.

```

#### arbitrary
```
This is a placeholder definition for the term 'arbitrary'.

```

#### are
```
This is a placeholder definition for the term 'are'.

```

#### arguments
```
This is a placeholder definition for the term 'arguments'.

```

#### arise
```
This is a placeholder definition for the term 'arise'.

```

#### arises
```
This is a placeholder definition for the term 'arises'.

```

#### arising
```
This is a placeholder definition for the term 'arising'.

```

#### around
```
This is a placeholder definition for the term 'around'.

```

#### aspect
```
This is a placeholder definition for the term 'aspect'.

```

#### aspect1
```
This is a placeholder definition for the term 'aspect1'.

```

#### aspect3
```
This is a placeholder definition for the term 'aspect3'.

```

#### aspects
```
This is a placeholder definition for the term 'aspects'.

```

#### asserted
```
This is a placeholder definition for the term 'asserted'.

```

#### asserting
```
This is a placeholder definition for the term 'asserting'.

```

#### assertion
```
This is a placeholder definition for the term 'assertion'.

```

#### assertions
```
This is a placeholder definition for the term 'assertions'.

```

#### asserts
```
This is a placeholder definition for the term 'asserts'.

```

#### assume
```
This is a placeholder definition for the term 'assume'.

```

#### assumed
```
This is a placeholder definition for the term 'assumed'.

```

#### assumptions
```
This is a placeholder definition for the term 'assumptions'.

```

#### atmosphere
```
This is a placeholder definition for the term 'atmosphere'.

```

#### attempt
```
This is a placeholder definition for the term 'attempt'.

```

#### attempted
```
This is a placeholder definition for the term 'attempted'.

```

#### attempting
```
This is a placeholder definition for the term 'attempting'.

```

#### attempts
```
This is a placeholder definition for the term 'attempts'.

```

#### available
```
This is a placeholder definition for the term 'available'.

```

#### avoid
```
This is a placeholder definition for the term 'avoid'.

```

#### axiom
```
This is a placeholder definition for the term 'axiom'.

```

#### axiomatization
```
This is a placeholder definition for the term 'axiomatization'.

```

#### axiomatize
```
This is a placeholder definition for the term 'axiomatize'.

```

#### axiomatizing
```
This is a placeholder definition for the term 'axiomatizing'.

```

#### axioms
```
This is a placeholder definition for the term 'axioms'.

```

#### aﬀect
```
This is a placeholder definition for the term 'aﬀect'.

```

#### backward
```
This is a placeholder definition for the term 'backward'.

```

#### bacteria
```
This is a placeholder definition for the term 'bacteria'.

```

#### bacterium
```
This is a placeholder definition for the term 'bacterium'.

```

#### baritone
```
This is a placeholder definition for the term 'baritone'.

```

#### based
```
This is a placeholder definition for the term 'based'.

```

#### basic
```
This is a placeholder definition for the term 'basic'.

```

#### because
```
This is a placeholder definition for the term 'because'.

```

#### before
```
This is a placeholder definition for the term 'before'.

```

#### beginning
```
This is a placeholder definition for the term 'beginning'.

```

#### begun
```
This is a placeholder definition for the term 'begun'.

```

#### behavior
```
This is a placeholder definition for the term 'behavior'.

```

#### behaviors
```
This is a placeholder definition for the term 'behaviors'.

```

#### being
```
This is a placeholder definition for the term 'being'.

```

#### belief
```
This is a placeholder definition for the term 'belief'.

```

#### beliefs
```
This is a placeholder definition for the term 'beliefs'.

```

#### better
```
This is a placeholder definition for the term 'better'.

```

#### between
```
This is a placeholder definition for the term 'between'.

```

#### beyond
```
This is a placeholder definition for the term 'beyond'.

```

#### birds
```
This is a placeholder definition for the term 'birds'.

```

#### blocks
```
This is a placeholder definition for the term 'blocks'.

```

#### body
```
This is a placeholder definition for the term 'body'.

```

#### brakes
```
This is a placeholder definition for the term 'brakes'.

```

#### build
```
This is a placeholder definition for the term 'build'.

```

#### built
```
This is a placeholder definition for the term 'built'.

```

#### buying
```
This is a placeholder definition for the term 'buying'.

```

#### calculus
```
This is a placeholder definition for the term 'calculus'.

```

#### called
```
This is a placeholder definition for the term 'called'.

```

#### calls
```
This is a placeholder definition for the term 'calls'.

```

#### cally
```
This is a placeholder definition for the term 'cally'.

```

#### candidate
```
This is a placeholder definition for the term 'candidate'.

```

#### canning
```
This is a placeholder definition for the term 'canning'.

```

#### cannot
```
This is a placeholder definition for the term 'cannot'.

```

#### can’t
```
This is a placeholder definition for the term 'can’t'.

```

#### careful
```
This is a placeholder definition for the term 'careful'.

```

#### carries
```
This is a placeholder definition for the term 'carries'.

```

#### cations
```
This is a placeholder definition for the term 'cations'.

```

#### causing
```
This is a placeholder definition for the term 'causing'.

```

#### centrifugal
```
This is a placeholder definition for the term 'centrifugal'.

```

#### certain
```
This is a placeholder definition for the term 'certain'.

```

#### chaining
```
This is a placeholder definition for the term 'chaining'.

```

#### change
```
This is a placeholder definition for the term 'change'.

```

#### changes
```
This is a placeholder definition for the term 'changes'.

```

#### changing
```
This is a placeholder definition for the term 'changing'.

```

#### chosen
```
This is a placeholder definition for the term 'chosen'.

```

#### circumscription
```
This is a placeholder definition for the term 'circumscription'.

```

#### circumstance
```
This is a placeholder definition for the term 'circumstance'.

```

#### circumstances
```
This is a placeholder definition for the term 'circumstances'.

```

#### class
```
This is a placeholder definition for the term 'class'.

```

#### clauses
```
This is a placeholder definition for the term 'clauses'.

```

#### clearly
```
This is a placeholder definition for the term 'clearly'.

```

#### colleagues
```
This is a placeholder definition for the term 'colleagues'.

```

#### collide
```
This is a placeholder definition for the term 'collide'.

```

#### color
```
This is a placeholder definition for the term 'color'.

```

#### color(x
```
This is a placeholder definition for the term 'color(x'.

```

#### color(y
```
This is a placeholder definition for the term 'color(y'.

```

#### colors
```
This is a placeholder definition for the term 'colors'.

```

#### combin
```
This is a placeholder definition for the term 'combin'.

```

#### combinatorial
```
This is a placeholder definition for the term 'combinatorial'.

```

#### combine
```
This is a placeholder definition for the term 'combine'.

```

#### comes
```
This is a placeholder definition for the term 'comes'.

```

#### common
```
This is a placeholder definition for the term 'common'.

```

#### commonsense
```
This is a placeholder definition for the term 'commonsense'.

```

#### communicate
```
This is a placeholder definition for the term 'communicate'.

```

#### communication
```
This is a placeholder definition for the term 'communication'.

```

#### communicator
```
This is a placeholder definition for the term 'communicator'.

```

#### complete
```
This is a placeholder definition for the term 'complete'.

```

#### completed
```
This is a placeholder definition for the term 'completed'.

```

#### completely
```
This is a placeholder definition for the term 'completely'.

```

#### complica
```
This is a placeholder definition for the term 'complica'.

```

#### comprehensiveness
```
This is a placeholder definition for the term 'comprehensiveness'.

```

#### comprises
```
This is a placeholder definition for the term 'comprises'.

```

#### computer
```
This is a placeholder definition for the term 'computer'.

```

#### concepts
```
This is a placeholder definition for the term 'concepts'.

```

#### conceptual
```
This is a placeholder definition for the term 'conceptual'.

```

#### concerned
```
This is a placeholder definition for the term 'concerned'.

```

#### concrete
```
This is a placeholder definition for the term 'concrete'.

```

#### concurrent
```
This is a placeholder definition for the term 'concurrent'.

```

#### conditions
```
This is a placeholder definition for the term 'conditions'.

```

#### consequence
```
This is a placeholder definition for the term 'consequence'.

```

#### consequences
```
This is a placeholder definition for the term 'consequences'.

```

#### consider
```
This is a placeholder definition for the term 'consider'.

```

#### considerably
```
This is a placeholder definition for the term 'considerably'.

```

#### considered
```
This is a placeholder definition for the term 'considered'.

```

#### consisting
```
This is a placeholder definition for the term 'consisting'.

```

#### constant
```
This is a placeholder definition for the term 'constant'.

```

#### constants
```
This is a placeholder definition for the term 'constants'.

```

#### constituted
```
This is a placeholder definition for the term 'constituted'.

```

#### construction
```
This is a placeholder definition for the term 'construction'.

```

#### consult
```
This is a placeholder definition for the term 'consult'.

```

#### contain
```
This is a placeholder definition for the term 'contain'.

```

#### container
```
This is a placeholder definition for the term 'container'.

```

#### contains
```
This is a placeholder definition for the term 'contains'.

```

#### contex
```
This is a placeholder definition for the term 'contex'.

```

#### context
```
This is a placeholder definition for the term 'context'.

```

#### contexts
```
This is a placeholder definition for the term 'contexts'.

```

#### context”
```
This is a placeholder definition for the term 'context”'.

```

#### continue
```
This is a placeholder definition for the term 'continue'.

```

#### continuing
```
This is a placeholder definition for the term 'continuing'.

```

#### continuum
```
This is a placeholder definition for the term 'continuum'.

```

#### contradictions
```
This is a placeholder definition for the term 'contradictions'.

```

#### control
```
This is a placeholder definition for the term 'control'.

```

#### controlling
```
This is a placeholder definition for the term 'controlling'.

```

#### convenient
```
This is a placeholder definition for the term 'convenient'.

```

#### copies
```
This is a placeholder definition for the term 'copies'.

```

#### correct
```
This is a placeholder definition for the term 'correct'.

```

#### correspond
```
This is a placeholder definition for the term 'correspond'.

```

#### corresponding
```
This is a placeholder definition for the term 'corresponding'.

```

#### could
```
This is a placeholder definition for the term 'could'.

```

#### counts
```
This is a placeholder definition for the term 'counts'.

```

#### covered
```
This is a placeholder definition for the term 'covered'.

```

#### crash
```
This is a placeholder definition for the term 'crash'.

```

#### creature
```
This is a placeholder definition for the term 'creature'.

```

#### criterion
```
This is a placeholder definition for the term 'criterion'.

```

#### critic
```
This is a placeholder definition for the term 'critic'.

```

#### current
```
This is a placeholder definition for the term 'current'.

```

#### custom
```
This is a placeholder definition for the term 'custom'.

```

#### daily
```
This is a placeholder definition for the term 'daily'.

```

#### database
```
This is a placeholder definition for the term 'database'.

```

#### databases
```
This is a placeholder definition for the term 'databases'.

```

#### dead
```
This is a placeholder definition for the term 'dead'.

```

#### decide
```
This is a placeholder definition for the term 'decide'.

```

#### decides
```
This is a placeholder definition for the term 'decides'.

```

#### declara
```
This is a placeholder definition for the term 'declara'.

```

#### declarative
```
This is a placeholder definition for the term 'declarative'.

```

#### declaratively
```
This is a placeholder definition for the term 'declaratively'.

```

#### deduction
```
This is a placeholder definition for the term 'deduction'.

```

#### defect
```
This is a placeholder definition for the term 'defect'.

```

#### delete
```
This is a placeholder definition for the term 'delete'.

```

#### delicately
```
This is a placeholder definition for the term 'delicately'.

```

#### depend
```
This is a placeholder definition for the term 'depend'.

```

#### depends
```
This is a placeholder definition for the term 'depends'.

```

#### derivation
```
This is a placeholder definition for the term 'derivation'.

```

#### described
```
This is a placeholder definition for the term 'described'.

```

#### details
```
This is a placeholder definition for the term 'details'.

```

#### determine
```
This is a placeholder definition for the term 'determine'.

```

#### devise
```
This is a placeholder definition for the term 'devise'.

```

#### deﬁni
```
This is a placeholder definition for the term 'deﬁni'.

```

#### didn’t
```
This is a placeholder definition for the term 'didn’t'.

```

#### dies
```
This is a placeholder definition for the term 'dies'.

```

#### directly
```
This is a placeholder definition for the term 'directly'.

```

#### disclaimer
```
This is a placeholder definition for the term 'disclaimer'.

```

#### discouraged
```
This is a placeholder definition for the term 'discouraged'.

```

#### discover
```
This is a placeholder definition for the term 'discover'.

```

#### discovered
```
This is a placeholder definition for the term 'discovered'.

```

#### discrete
```
This is a placeholder definition for the term 'discrete'.

```

#### discussed
```
This is a placeholder definition for the term 'discussed'.

```

#### disparate
```
This is a placeholder definition for the term 'disparate'.

```

#### distinction
```
This is a placeholder definition for the term 'distinction'.

```

#### diﬀers
```
This is a placeholder definition for the term 'diﬀers'.

```

#### diﬃculties
```
This is a placeholder definition for the term 'diﬃculties'.

```

#### doctor
```
This is a placeholder definition for the term 'doctor'.

```

#### doesn’t
```
This is a placeholder definition for the term 'doesn’t'.

```

#### domain
```
This is a placeholder definition for the term 'domain'.

```

#### domains
```
This is a placeholder definition for the term 'domains'.

```

#### don’t
```
This is a placeholder definition for the term 'don’t'.

```

#### duplicates
```
This is a placeholder definition for the term 'duplicates'.

```

#### early
```
This is a placeholder definition for the term 'early'.

```

#### easily
```
This is a placeholder definition for the term 'easily'.

```

#### ed
```
This is a placeholder definition for the term 'ed'.

```

#### eds
```
This is a placeholder definition for the term 'eds'.

```

#### elusive
```
This is a placeholder definition for the term 'elusive'.

```

#### embody
```
This is a placeholder definition for the term 'embody'.

```

#### emphasizes
```
This is a placeholder definition for the term 'emphasizes'.

```

#### encased
```
This is a placeholder definition for the term 'encased'.

```

#### encounter
```
This is a placeholder definition for the term 'encounter'.

```

#### engineer”
```
This is a placeholder definition for the term 'engineer”'.

```

#### enough
```
This is a placeholder definition for the term 'enough'.

```

#### entering
```
This is a placeholder definition for the term 'entering'.

```

#### entirely
```
This is a placeholder definition for the term 'entirely'.

```

#### entities
```
This is a placeholder definition for the term 'entities'.

```

#### entitled
```
This is a placeholder definition for the term 'entitled'.

```

#### entry
```
This is a placeholder definition for the term 'entry'.

```

#### epistemological
```
This is a placeholder definition for the term 'epistemological'.

```

#### epistemologically
```
This is a placeholder definition for the term 'epistemologically'.

```

#### epistemology
```
This is a placeholder definition for the term 'epistemology'.

```

#### equivalent
```
This is a placeholder definition for the term 'equivalent'.

```

#### especially
```
This is a placeholder definition for the term 'especially'.

```

#### essential
```
This is a placeholder definition for the term 'essential'.

```

#### event
```
This is a placeholder definition for the term 'event'.

```

#### events
```
This is a placeholder definition for the term 'events'.

```

#### eventually
```
This is a placeholder definition for the term 'eventually'.

```

#### ever
```
This is a placeholder definition for the term 'ever'.

```

#### evolution;
```
This is a placeholder definition for the term 'evolution;'.

```

#### example
```
This is a placeholder definition for the term 'example'.

```

#### examples
```
This is a placeholder definition for the term 'examples'.

```

#### except
```
This is a placeholder definition for the term 'except'.

```

#### exceptions
```
This is a placeholder definition for the term 'exceptions'.

```

#### exchange
```
This is a placeholder definition for the term 'exchange'.

```

#### existence
```
This is a placeholder definition for the term 'existence'.

```

#### existential
```
This is a placeholder definition for the term 'existential'.

```

#### expected
```
This is a placeholder definition for the term 'expected'.

```

#### experience
```
This is a placeholder definition for the term 'experience'.

```

#### experiment
```
This is a placeholder definition for the term 'experiment'.

```

#### experiments
```
This is a placeholder definition for the term 'experiments'.

```

#### expert
```
This is a placeholder definition for the term 'expert'.

```

#### explain
```
This is a placeholder definition for the term 'explain'.

```

#### explicit
```
This is a placeholder definition for the term 'explicit'.

```

#### explicitly
```
This is a placeholder definition for the term 'explicitly'.

```

#### explosion
```
This is a placeholder definition for the term 'explosion'.

```

#### express
```
This is a placeholder definition for the term 'express'.

```

#### expressed
```
This is a placeholder definition for the term 'expressed'.

```

#### expressing
```
This is a placeholder definition for the term 'expressing'.

```

#### expression
```
This is a placeholder definition for the term 'expression'.

```

#### expressions
```
This is a placeholder definition for the term 'expressions'.

```

#### expressive
```
This is a placeholder definition for the term 'expressive'.

```

#### expressiveness
```
This is a placeholder definition for the term 'expressiveness'.

```

#### extensions
```
This is a placeholder definition for the term 'extensions'.

```

#### eﬀects
```
This is a placeholder definition for the term 'eﬀects'.

```

#### facility
```
This is a placeholder definition for the term 'facility'.

```

#### facts
```
This is a placeholder definition for the term 'facts'.

```

#### failure
```
This is a placeholder definition for the term 'failure'.

```

#### fairly
```
This is a placeholder definition for the term 'fairly'.

```

#### familiarity
```
This is a placeholder definition for the term 'familiarity'.

```

#### family
```
This is a placeholder definition for the term 'family'.

```

#### feasible
```
This is a placeholder definition for the term 'feasible'.

```

#### features
```
This is a placeholder definition for the term 'features'.

```

#### follow
```
This is a placeholder definition for the term 'follow'.

```

#### following
```
This is a placeholder definition for the term 'following'.

```

#### follows
```
This is a placeholder definition for the term 'follows'.

```

#### force
```
This is a placeholder definition for the term 'force'.

```

#### form
```
This is a placeholder definition for the term 'form'.

```

#### formal
```
This is a placeholder definition for the term 'formal'.

```

#### formalism
```
This is a placeholder definition for the term 'formalism'.

```

#### formalizations
```
This is a placeholder definition for the term 'formalizations'.

```

#### formalized
```
This is a placeholder definition for the term 'formalized'.

```

#### formalizing
```
This is a placeholder definition for the term 'formalizing'.

```

#### forming
```
This is a placeholder definition for the term 'forming'.

```

#### formulas
```
This is a placeholder definition for the term 'formulas'.

```

#### formulating
```
This is a placeholder definition for the term 'formulating'.

```

#### fortunately
```
This is a placeholder definition for the term 'fortunately'.

```

#### fortune
```
This is a placeholder definition for the term 'fortune'.

```

#### found
```
This is a placeholder definition for the term 'found'.

```

#### fragment
```
This is a placeholder definition for the term 'fragment'.

```

#### frame
```
This is a placeholder definition for the term 'frame'.

```

#### froma
```
This is a placeholder definition for the term 'froma'.

```

#### fulﬁlled
```
This is a placeholder definition for the term 'fulﬁlled'.

```

#### func
```
This is a placeholder definition for the term 'func'.

```

#### function
```
This is a placeholder definition for the term 'function'.

```

#### functions
```
This is a placeholder definition for the term 'functions'.

```

#### fundamental
```
This is a placeholder definition for the term 'fundamental'.

```

#### further
```
This is a placeholder definition for the term 'further'.

```

#### gence
```
This is a placeholder definition for the term 'gence'.

```

#### general
```
This is a placeholder definition for the term 'general'.

```

#### generality
```
This is a placeholder definition for the term 'generality'.

```

#### generalization
```
This is a placeholder definition for the term 'generalization'.

```

#### generate
```
This is a placeholder definition for the term 'generate'.

```

#### genetic
```
This is a placeholder definition for the term 'genetic'.

```

#### getting
```
This is a placeholder definition for the term 'getting'.

```

#### given
```
This is a placeholder definition for the term 'given'.

```

#### goal
```
This is a placeholder definition for the term 'goal'.

```

#### goal
```
This is a placeholder definition for the term 'goal'.

```

#### goals
```
This is a placeholder definition for the term 'goals'.

```

#### grateful
```
This is a placeholder definition for the term 'grateful'.

```

#### gravity
```
This is a placeholder definition for the term 'gravity'.

```

#### gross
```
This is a placeholder definition for the term 'gross'.

```

#### ground
```
This is a placeholder definition for the term 'ground'.

```

#### grown
```
This is a placeholder definition for the term 'grown'.

```

#### guess
```
This is a placeholder definition for the term 'guess'.

```

#### haggle
```
This is a placeholder definition for the term 'haggle'.

```

#### handle
```
This is a placeholder definition for the term 'handle'.

```

#### having
```
This is a placeholder definition for the term 'having'.

```

#### heard
```
This is a placeholder definition for the term 'heard'.

```

#### heated
```
This is a placeholder definition for the term 'heated'.

```

#### heating
```
This is a placeholder definition for the term 'heating'.

```

#### heavily
```
This is a placeholder definition for the term 'heavily'.

```

#### heuristic
```
This is a placeholder definition for the term 'heuristic'.

```

#### history
```
This is a placeholder definition for the term 'history'.

```

#### hold
```
This is a placeholder definition for the term 'hold'.

```

#### holds(c1
```
This is a placeholder definition for the term 'holds(c1'.

```

#### holds(p
```
This is a placeholder definition for the term 'holds(p'.

```

#### holds(q
```
This is a placeholder definition for the term 'holds(q'.

```

#### http://www-formal.stanford.edu/jmc/
```
This is a placeholder definition for the term 'http://www-formal.stanford.edu/jmc/'.

```

#### human
```
This is a placeholder definition for the term 'human'.

```

#### humans
```
This is a placeholder definition for the term 'humans'.

```

#### ideas
```
This is a placeholder definition for the term 'ideas'.

```

#### identiﬁcations
```
This is a placeholder definition for the term 'identiﬁcations'.

```

#### ilize
```
This is a placeholder definition for the term 'ilize'.

```

#### illness
```
This is a placeholder definition for the term 'illness'.

```

#### imagine
```
This is a placeholder definition for the term 'imagine'.

```

#### imagined
```
This is a placeholder definition for the term 'imagined'.

```

#### immediately
```
This is a placeholder definition for the term 'immediately'.

```

#### implementation
```
This is a placeholder definition for the term 'implementation'.

```

#### implicitly
```
This is a placeholder definition for the term 'implicitly'.

```

#### imply
```
This is a placeholder definition for the term 'imply'.

```

#### improve
```
This is a placeholder definition for the term 'improve'.

```

#### improved
```
This is a placeholder definition for the term 'improved'.

```

#### improving
```
This is a placeholder definition for the term 'improving'.

```

#### include
```
This is a placeholder definition for the term 'include'.

```

#### included
```
This is a placeholder definition for the term 'included'.

```

#### including
```
This is a placeholder definition for the term 'including'.

```

#### inclusion
```
This is a placeholder definition for the term 'inclusion'.

```

#### incorporating
```
This is a placeholder definition for the term 'incorporating'.

```

#### increase
```
This is a placeholder definition for the term 'increase'.

```

#### increased
```
This is a placeholder definition for the term 'increased'.

```

#### increasing
```
This is a placeholder definition for the term 'increasing'.

```

#### independent
```
This is a placeholder definition for the term 'independent'.

```

#### indicates
```
This is a placeholder definition for the term 'indicates'.

```

#### individually
```
This is a placeholder definition for the term 'individually'.

```

#### infer
```
This is a placeholder definition for the term 'infer'.

```

#### inference
```
This is a placeholder definition for the term 'inference'.

```

#### inferior
```
This is a placeholder definition for the term 'inferior'.

```

#### informa
```
This is a placeholder definition for the term 'informa'.

```

#### information
```
This is a placeholder definition for the term 'information'.

```

#### ingenuity
```
This is a placeholder definition for the term 'ingenuity'.

```

#### inheritance
```
This is a placeholder definition for the term 'inheritance'.

```

#### inherited
```
This is a placeholder definition for the term 'inherited'.

```

#### initial
```
This is a placeholder definition for the term 'initial'.

```

#### input
```
This is a placeholder definition for the term 'input'.

```

#### instances
```
This is a placeholder definition for the term 'instances'.

```

#### instructions
```
This is a placeholder definition for the term 'instructions'.

```

#### intelligent
```
This is a placeholder definition for the term 'intelligent'.

```

#### intended
```
This is a placeholder definition for the term 'intended'.

```

#### intermediate
```
This is a placeholder definition for the term 'intermediate'.

```

#### internal
```
This is a placeholder definition for the term 'internal'.

```

#### internally
```
This is a placeholder definition for the term 'internally'.

```

#### interpreted
```
This is a placeholder definition for the term 'interpreted'.

```

#### introduction
```
This is a placeholder definition for the term 'introduction'.

```

#### inventing
```
This is a placeholder definition for the term 'inventing'.

```

#### involve
```
This is a placeholder definition for the term 'involve'.

```

#### involved
```
This is a placeholder definition for the term 'involved'.

```

#### involves
```
This is a placeholder definition for the term 'involves'.

```

#### inﬁnite
```
This is a placeholder definition for the term 'inﬁnite'.

```

#### isn’t
```
This is a placeholder definition for the term 'isn’t'.

```

#### jmc@cs.stanford.edu
```
This is a placeholder definition for the term 'jmc@cs.stanford.edu'.

```

#### killing
```
This is a placeholder definition for the term 'killing'.

```

#### kind
```
This is a placeholder definition for the term 'kind'.

```

#### kinds
```
This is a placeholder definition for the term 'kinds'.

```

#### knowledge
```
This is a placeholder definition for the term 'knowledge'.

```

#### knows
```
This is a placeholder definition for the term 'knows'.

```

#### laboratory
```
This is a placeholder definition for the term 'laboratory'.

```

#### language
```
This is a placeholder definition for the term 'language'.

```

#### languages
```
This is a placeholder definition for the term 'languages'.

```

#### later
```
This is a placeholder definition for the term 'later'.

```

#### latexed
```
This is a placeholder definition for the term 'latexed'.

```

#### leads
```
This is a placeholder definition for the term 'leads'.

```

#### learn
```
This is a placeholder definition for the term 'learn'.

```

#### learning
```
This is a placeholder definition for the term 'learning'.

```

#### leaving
```
This is a placeholder definition for the term 'leaving'.

```

#### lecture
```
This is a placeholder definition for the term 'lecture'.

```

#### length
```
This is a placeholder definition for the term 'length'.

```

#### level
```
This is a placeholder definition for the term 'level'.

```

#### life
```
This is a placeholder definition for the term 'life'.

```

#### like
```
This is a placeholder definition for the term 'like'.

```

#### likely
```
This is a placeholder definition for the term 'likely'.

```

#### limit
```
This is a placeholder definition for the term 'limit'.

```

#### limitation
```
This is a placeholder definition for the term 'limitation'.

```

#### limitations
```
This is a placeholder definition for the term 'limitations'.

```

#### little
```
This is a placeholder definition for the term 'little'.

```

#### loc(x
```
This is a placeholder definition for the term 'loc(x'.

```

#### loc(y
```
This is a placeholder definition for the term 'loc(y'.

```

#### local
```
This is a placeholder definition for the term 'local'.

```

#### location
```
This is a placeholder definition for the term 'location'.

```

#### locations
```
This is a placeholder definition for the term 'locations'.

```

#### logic
```
This is a placeholder definition for the term 'logic'.

```

#### logic-based
```
This is a placeholder definition for the term 'logic-based'.

```

#### logical
```
This is a placeholder definition for the term 'logical'.

```

#### longer
```
This is a placeholder definition for the term 'longer'.

```

#### machine
```
This is a placeholder definition for the term 'machine'.

```

#### made
```
This is a placeholder definition for the term 'made'.

```

#### mainly
```
This is a placeholder definition for the term 'mainly'.

```

#### major
```
This is a placeholder definition for the term 'major'.

```

#### makes
```
This is a placeholder definition for the term 'makes'.

```

#### making
```
This is a placeholder definition for the term 'making'.

```

#### mann
```
This is a placeholder definition for the term 'mann'.

```

#### manner
```
This is a placeholder definition for the term 'manner'.

```

#### match
```
This is a placeholder definition for the term 'match'.

```

#### matters
```
This is a placeholder definition for the term 'matters'.

```

#### meaning
```
This is a placeholder definition for the term 'meaning'.

```

#### means
```
This is a placeholder definition for the term 'means'.

```

#### mechanism
```
This is a placeholder definition for the term 'mechanism'.

```

#### mechanisms
```
This is a placeholder definition for the term 'mechanisms'.

```

#### mechansims
```
This is a placeholder definition for the term 'mechansims'.

```

#### medium
```
This is a placeholder definition for the term 'medium'.

```

#### meeting
```
This is a placeholder definition for the term 'meeting'.

```

#### memory
```
This is a placeholder definition for the term 'memory'.

```

#### method
```
This is a placeholder definition for the term 'method'.

```

#### methods
```
This is a placeholder definition for the term 'methods'.

```

#### might
```
This is a placeholder definition for the term 'might'.

```

#### modify
```
This is a placeholder definition for the term 'modify'.

```

#### modifying
```
This is a placeholder definition for the term 'modifying'.

```

#### modiﬁ
```
This is a placeholder definition for the term 'modiﬁ'.

```

#### modiﬁca
```
This is a placeholder definition for the term 'modiﬁca'.

```

#### modiﬁcation
```
This is a placeholder definition for the term 'modiﬁcation'.

```

#### modiﬁcations
```
This is a placeholder definition for the term 'modiﬁcations'.

```

#### modiﬁed
```
This is a placeholder definition for the term 'modiﬁed'.

```

#### modularizing
```
This is a placeholder definition for the term 'modularizing'.

```

#### move(x
```
This is a placeholder definition for the term 'move(x'.

```

#### moving
```
This is a placeholder definition for the term 'moving'.

```

#### names
```
This is a placeholder definition for the term 'names'.

```

#### natural
```
This is a placeholder definition for the term 'natural'.

```

#### necesary
```
This is a placeholder definition for the term 'necesary'.

```

#### necessary
```
This is a placeholder definition for the term 'necessary'.

```

#### needed
```
This is a placeholder definition for the term 'needed'.

```

#### needs
```
This is a placeholder definition for the term 'needs'.

```

#### never
```
This is a placeholder definition for the term 'never'.

```

#### no-one
```
This is a placeholder definition for the term 'no-one'.

```

#### noise
```
This is a placeholder definition for the term 'noise'.

```

#### nonlogical
```
This is a placeholder definition for the term 'nonlogical'.

```

#### nonmonotonic
```
This is a placeholder definition for the term 'nonmonotonic'.

```

#### nonmonotonically
```
This is a placeholder definition for the term 'nonmonotonically'.

```

#### normally
```
This is a placeholder definition for the term 'normally'.

```

#### notation
```
This is a placeholder definition for the term 'notation'.

```

#### noted
```
This is a placeholder definition for the term 'noted'.

```

#### noticed
```
This is a placeholder definition for the term 'noticed'.

```

#### notion
```
This is a placeholder definition for the term 'notion'.

```

#### notions
```
This is a placeholder definition for the term 'notions'.

```

#### number
```
This is a placeholder definition for the term 'number'.

```

#### object
```
This is a placeholder definition for the term 'object'.

```

#### objective
```
This is a placeholder definition for the term 'objective'.

```

#### objects
```
This is a placeholder definition for the term 'objects'.

```

#### observation
```
This is a placeholder definition for the term 'observation'.

```

#### obstacle
```
This is a placeholder definition for the term 'obstacle'.

```

#### obtainable
```
This is a placeholder definition for the term 'obtainable'.

```

#### obvious
```
This is a placeholder definition for the term 'obvious'.

```

#### occuring
```
This is a placeholder definition for the term 'occuring'.

```

#### occurs
```
This is a placeholder definition for the term 'occurs'.

```

#### often
```
This is a placeholder definition for the term 'often'.

```

#### omitting
```
This is a placeholder definition for the term 'omitting'.

```

#### once
```
This is a placeholder definition for the term 'once'.

```

#### one’s
```
This is a placeholder definition for the term 'one’s'.

```

#### only
```
This is a placeholder definition for the term 'only'.

```

#### opera
```
This is a placeholder definition for the term 'opera'.

```

#### operations
```
This is a placeholder definition for the term 'operations'.

```

#### opinion
```
This is a placeholder definition for the term 'opinion'.

```

#### opportunity
```
This is a placeholder definition for the term 'opportunity'.

```

#### optimum
```
This is a placeholder definition for the term 'optimum'.

```

#### order
```
This is a placeholder definition for the term 'order'.

```

#### organisms
```
This is a placeholder definition for the term 'organisms'.

```

#### original
```
This is a placeholder definition for the term 'original'.

```

#### other
```
This is a placeholder definition for the term 'other'.

```

#### others
```
This is a placeholder definition for the term 'others'.

```

#### overambitious
```
This is a placeholder definition for the term 'overambitious'.

```

#### paint(x
```
This is a placeholder definition for the term 'paint(x'.

```

#### painting
```
This is a placeholder definition for the term 'painting'.

```

#### paper
```
This is a placeholder definition for the term 'paper'.

```

#### parameter
```
This is a placeholder definition for the term 'parameter'.

```

#### particular
```
This is a placeholder definition for the term 'particular'.

```

#### pattern
```
This is a placeholder definition for the term 'pattern'.

```

#### pattern-action
```
This is a placeholder definition for the term 'pattern-action'.

```

#### penguins
```
This is a placeholder definition for the term 'penguins'.

```

#### people
```
This is a placeholder definition for the term 'people'.

```

#### perfect
```
This is a placeholder definition for the term 'perfect'.

```

#### performance
```
This is a placeholder definition for the term 'performance'.

```

#### performed
```
This is a placeholder definition for the term 'performed'.

```

#### perhaps
```
This is a placeholder definition for the term 'perhaps'.

```

#### permit
```
This is a placeholder definition for the term 'permit'.

```

#### person
```
This is a placeholder definition for the term 'person'.

```

#### personal
```
This is a placeholder definition for the term 'personal'.

```

#### phenomenon
```
This is a placeholder definition for the term 'phenomenon'.

```

#### pioneered
```
This is a placeholder definition for the term 'pioneered'.

```

#### place
```
This is a placeholder definition for the term 'place'.

```

#### pletely
```
This is a placeholder definition for the term 'pletely'.

```

#### plexity
```
This is a placeholder definition for the term 'plexity'.

```

#### point
```
This is a placeholder definition for the term 'point'.

```

#### possessed
```
This is a placeholder definition for the term 'possessed'.

```

#### possibility
```
This is a placeholder definition for the term 'possibility'.

```

#### possible
```
This is a placeholder definition for the term 'possible'.

```

#### postponed
```
This is a placeholder definition for the term 'postponed'.

```

#### power
```
This is a placeholder definition for the term 'power'.

```

#### precise
```
This is a placeholder definition for the term 'precise'.

```

#### predicate
```
This is a placeholder definition for the term 'predicate'.

```

#### predicates
```
This is a placeholder definition for the term 'predicates'.

```

#### predictions
```
This is a placeholder definition for the term 'predictions'.

```

#### preliminary
```
This is a placeholder definition for the term 'preliminary'.

```

#### premisses
```
This is a placeholder definition for the term 'premisses'.

```

#### present
```
This is a placeholder definition for the term 'present'.

```

#### preventing
```
This is a placeholder definition for the term 'preventing'.

```

#### price
```
This is a placeholder definition for the term 'price'.

```

#### principle
```
This is a placeholder definition for the term 'principle'.

```

#### probability
```
This is a placeholder definition for the term 'probability'.

```

#### probably
```
This is a placeholder definition for the term 'probably'.

```

#### problem
```
This is a placeholder definition for the term 'problem'.

```

#### problems
```
This is a placeholder definition for the term 'problems'.

```

#### procedures
```
This is a placeholder definition for the term 'procedures'.

```

#### process
```
This is a placeholder definition for the term 'process'.

```

#### processes
```
This is a placeholder definition for the term 'processes'.

```

#### produced
```
This is a placeholder definition for the term 'produced'.

```

#### production
```
This is a placeholder definition for the term 'production'.

```

#### productions
```
This is a placeholder definition for the term 'productions'.

```

#### program
```
This is a placeholder definition for the term 'program'.

```

#### programmer
```
This is a placeholder definition for the term 'programmer'.

```

#### programming
```
This is a placeholder definition for the term 'programming'.

```

#### programs
```
This is a placeholder definition for the term 'programs'.

```

#### progress
```
This is a placeholder definition for the term 'progress'.

```

#### project
```
This is a placeholder definition for the term 'project'.

```

#### projects
```
This is a placeholder definition for the term 'projects'.

```

#### proliferation
```
This is a placeholder definition for the term 'proliferation'.

```

#### prominent
```
This is a placeholder definition for the term 'prominent'.

```

#### proportional
```
This is a placeholder definition for the term 'proportional'.

```

#### proposals
```
This is a placeholder definition for the term 'proposals'.

```

#### propose
```
This is a placeholder definition for the term 'propose'.

```

#### proposed
```
This is a placeholder definition for the term 'proposed'.

```

#### propositional
```
This is a placeholder definition for the term 'propositional'.

```

#### propositions
```
This is a placeholder definition for the term 'propositions'.

```

#### provers
```
This is a placeholder definition for the term 'provers'.

```

#### provide
```
This is a placeholder definition for the term 'provide'.

```

#### provided
```
This is a placeholder definition for the term 'provided'.

```

#### provides
```
This is a placeholder definition for the term 'provides'.

```

#### psychologist
```
This is a placeholder definition for the term 'psychologist'.

```

#### psychology
```
This is a placeholder definition for the term 'psychology'.

```

#### purpose
```
This is a placeholder definition for the term 'purpose'.

```

#### pursue
```
This is a placeholder definition for the term 'pursue'.

```

#### pursuing
```
This is a placeholder definition for the term 'pursuing'.

```

#### puter
```
This is a placeholder definition for the term 'puter'.

```

#### putting
```
This is a placeholder definition for the term 'putting'.

```

#### puzzles
```
This is a placeholder definition for the term 'puzzles'.

```

#### qualiﬁcation
```
This is a placeholder definition for the term 'qualiﬁcation'.

```

#### qualiﬁcations
```
This is a placeholder definition for the term 'qualiﬁcations'.

```

#### qualiﬁed
```
This is a placeholder definition for the term 'qualiﬁed'.

```

#### quantiﬁers
```
This is a placeholder definition for the term 'quantiﬁers'.

```

#### random
```
This is a placeholder definition for the term 'random'.

```

#### range
```
This is a placeholder definition for the term 'range'.

```

#### rapid
```
This is a placeholder definition for the term 'rapid'.

```

#### rarely
```
This is a placeholder definition for the term 'rarely'.

```

#### rather
```
This is a placeholder definition for the term 'rather'.

```

#### rationale
```
This is a placeholder definition for the term 'rationale'.

```

#### rationalize
```
This is a placeholder definition for the term 'rationalize'.

```

#### rationalizing
```
This is a placeholder definition for the term 'rationalizing'.

```

#### realized
```
This is a placeholder definition for the term 'realized'.

```

#### really
```
This is a placeholder definition for the term 'really'.

```

#### reason
```
This is a placeholder definition for the term 'reason'.

```

#### reasonable
```
This is a placeholder definition for the term 'reasonable'.

```

#### reasoned
```
This is a placeholder definition for the term 'reasoned'.

```

#### reasoning
```
This is a placeholder definition for the term 'reasoning'.

```

#### reasons
```
This is a placeholder definition for the term 'reasons'.

```

#### received
```
This is a placeholder definition for the term 'received'.

```

#### reduced
```
This is a placeholder definition for the term 'reduced'.

```

#### reducing
```
This is a placeholder definition for the term 'reducing'.

```

#### reference
```
This is a placeholder definition for the term 'reference'.

```

#### refers
```
This is a placeholder definition for the term 'refers'.

```

#### regard
```
This is a placeholder definition for the term 'regard'.

```

#### regarded
```
This is a placeholder definition for the term 'regarded'.

```

#### reiﬁcation
```
This is a placeholder definition for the term 'reiﬁcation'.

```

#### relating
```
This is a placeholder definition for the term 'relating'.

```

#### relation
```
This is a placeholder definition for the term 'relation'.

```

#### relatively
```
This is a placeholder definition for the term 'relatively'.

```

#### relevant
```
This is a placeholder definition for the term 'relevant'.

```

#### relies
```
This is a placeholder definition for the term 'relies'.

```

#### remains
```
This is a placeholder definition for the term 'remains'.

```

#### repeat
```
This is a placeholder definition for the term 'repeat'.

```

#### represent
```
This is a placeholder definition for the term 'represent'.

```

#### representable
```
This is a placeholder definition for the term 'representable'.

```

#### representation
```
This is a placeholder definition for the term 'representation'.

```

#### represented
```
This is a placeholder definition for the term 'represented'.

```

#### representing
```
This is a placeholder definition for the term 'representing'.

```

#### represents
```
This is a placeholder definition for the term 'represents'.

```

#### require
```
This is a placeholder definition for the term 'require'.

```

#### required
```
This is a placeholder definition for the term 'required'.

```

#### requires
```
This is a placeholder definition for the term 'requires'.

```

#### resembles
```
This is a placeholder definition for the term 'resembles'.

```

#### reserved
```
This is a placeholder definition for the term 'reserved'.

```

#### restricted
```
This is a placeholder definition for the term 'restricted'.

```

#### restrictions
```
This is a placeholder definition for the term 'restrictions'.

```

#### result
```
This is a placeholder definition for the term 'result'.

```

#### result(e
```
This is a placeholder definition for the term 'result(e'.

```

#### result(e1
```
This is a placeholder definition for the term 'result(e1'.

```

#### result(e2
```
This is a placeholder definition for the term 'result(e2'.

```

#### result(move(x
```
This is a placeholder definition for the term 'result(move(x'.

```

#### result(paint(x
```
This is a placeholder definition for the term 'result(paint(x'.

```

#### result(paint(y
```
This is a placeholder definition for the term 'result(paint(y'.

```

#### resulted
```
This is a placeholder definition for the term 'resulted'.

```

#### results
```
This is a placeholder definition for the term 'results'.

```

#### reviewed
```
This is a placeholder definition for the term 'reviewed'.

```

#### rewarding
```
This is a placeholder definition for the term 'rewarding'.

```

#### rewrite
```
This is a placeholder definition for the term 'rewrite'.

```

#### rewriting
```
This is a placeholder definition for the term 'rewriting'.

```

#### reﬂected
```
This is a placeholder definition for the term 'reﬂected'.

```

#### robot
```
This is a placeholder definition for the term 'robot'.

```

#### rule
```
This is a placeholder definition for the term 'rule'.

```

#### rules
```
This is a placeholder definition for the term 'rules'.

```

#### rumor
```
This is a placeholder definition for the term 'rumor'.

```

#### s)∧clear(l
```
This is a placeholder definition for the term 's)∧clear(l'.

```

#### s)∧¬tooheavy(x
```
This is a placeholder definition for the term 's)∧¬tooheavy(x'.

```

#### satisfactory
```
This is a placeholder definition for the term 'satisfactory'.

```

#### satisfy
```
This is a placeholder definition for the term 'satisfy'.

```

#### saying
```
This is a placeholder definition for the term 'saying'.

```

#### scheme
```
This is a placeholder definition for the term 'scheme'.

```

#### schemes
```
This is a placeholder definition for the term 'schemes'.

```

#### science
```
This is a placeholder definition for the term 'science'.

```

#### scope
```
This is a placeholder definition for the term 'scope'.

```

#### scrapping
```
This is a placeholder definition for the term 'scrapping'.

```

#### sealed
```
This is a placeholder definition for the term 'sealed'.

```

#### sealing
```
This is a placeholder definition for the term 'sealing'.

```

#### search
```
This is a placeholder definition for the term 'search'.

```

#### second
```
This is a placeholder definition for the term 'second'.

```

#### section
```
This is a placeholder definition for the term 'section'.

```

#### seeking
```
This is a placeholder definition for the term 'seeking'.

```

#### seemed
```
This is a placeholder definition for the term 'seemed'.

```

#### seems
```
This is a placeholder definition for the term 'seems'.

```

#### selling
```
This is a placeholder definition for the term 'selling'.

```

#### sense
```
This is a placeholder definition for the term 'sense'.

```

#### sentence
```
This is a placeholder definition for the term 'sentence'.

```

#### sentences
```
This is a placeholder definition for the term 'sentences'.

```

#### separate
```
This is a placeholder definition for the term 'separate'.

```

#### sequence
```
This is a placeholder definition for the term 'sequence'.

```

#### sertation
```
This is a placeholder definition for the term 'sertation'.

```

#### several
```
This is a placeholder definition for the term 'several'.

```

#### sharp
```
This is a placeholder definition for the term 'sharp'.

```

#### shells
```
This is a placeholder definition for the term 'shells'.

```

#### should
```
This is a placeholder definition for the term 'should'.

```

#### shown
```
This is a placeholder definition for the term 'shown'.

```

#### shows
```
This is a placeholder definition for the term 'shows'.

```

#### signiﬁcant
```
This is a placeholder definition for the term 'signiﬁcant'.

```

#### similar
```
This is a placeholder definition for the term 'similar'.

```

#### similarity
```
This is a placeholder definition for the term 'similarity'.

```

#### simple
```
This is a placeholder definition for the term 'simple'.

```

#### simplest
```
This is a placeholder definition for the term 'simplest'.

```

#### simpliﬁcation
```
This is a placeholder definition for the term 'simpliﬁcation'.

```

#### simply
```
This is a placeholder definition for the term 'simply'.

```

#### since
```
This is a placeholder definition for the term 'since'.

```

#### single
```
This is a placeholder definition for the term 'single'.

```

#### situation
```
This is a placeholder definition for the term 'situation'.

```

#### situations
```
This is a placeholder definition for the term 'situations'.

```

#### slightly
```
This is a placeholder definition for the term 'slightly'.

```

#### slowly
```
This is a placeholder definition for the term 'slowly'.

```

#### small
```
This is a placeholder definition for the term 'small'.

```

#### solutions
```
This is a placeholder definition for the term 'solutions'.

```

#### solver
```
This is a placeholder definition for the term 'solver'.

```

#### solving
```
This is a placeholder definition for the term 'solving'.

```

#### something
```
This is a placeholder definition for the term 'something'.

```

#### soning
```
This is a placeholder definition for the term 'soning'.

```

#### spacecraft
```
This is a placeholder definition for the term 'spacecraft'.

```

#### special
```
This is a placeholder definition for the term 'special'.

```

#### speciﬁ
```
This is a placeholder definition for the term 'speciﬁ'.

```

#### speciﬁc
```
This is a placeholder definition for the term 'speciﬁc'.

```

#### spent
```
This is a placeholder definition for the term 'spent'.

```

#### squeal
```
This is a placeholder definition for the term 'squeal'.

```

#### standard
```
This is a placeholder definition for the term 'standard'.

```

#### stant
```
This is a placeholder definition for the term 'stant'.

```

#### stants
```
This is a placeholder definition for the term 'stants'.

```

#### state
```
This is a placeholder definition for the term 'state'.

```

#### stated
```
This is a placeholder definition for the term 'stated'.

```

#### statements
```
This is a placeholder definition for the term 'statements'.

```

#### states
```
This is a placeholder definition for the term 'states'.

```

#### ster
```
This is a placeholder definition for the term 'ster'.

```

#### sterile
```
This is a placeholder definition for the term 'sterile'.

```

#### sterilize
```
This is a placeholder definition for the term 'sterilize'.

```

#### still
```
This is a placeholder definition for the term 'still'.

```

#### stories
```
This is a placeholder definition for the term 'stories'.

```

#### strat
```
This is a placeholder definition for the term 'strat'.

```

#### strategies
```
This is a placeholder definition for the term 'strategies'.

```

#### strategy
```
This is a placeholder definition for the term 'strategy'.

```

#### strong
```
This is a placeholder definition for the term 'strong'.

```

#### structure
```
This is a placeholder definition for the term 'structure'.

```

#### structures
```
This is a placeholder definition for the term 'structures'.

```

#### students
```
This is a placeholder definition for the term 'students'.

```

#### studied
```
This is a placeholder definition for the term 'studied'.

```

#### subgoals
```
This is a placeholder definition for the term 'subgoals'.

```

#### subject
```
This is a placeholder definition for the term 'subject'.

```

#### subroutine
```
This is a placeholder definition for the term 'subroutine'.

```

#### subroutines
```
This is a placeholder definition for the term 'subroutines'.

```

#### subsequently
```
This is a placeholder definition for the term 'subsequently'.

```

#### substantiated
```
This is a placeholder definition for the term 'substantiated'.

```

#### substitute
```
This is a placeholder definition for the term 'substitute'.

```

#### substituting
```
This is a placeholder definition for the term 'substituting'.

```

#### substitution
```
This is a placeholder definition for the term 'substitution'.

```

#### succeed
```
This is a placeholder definition for the term 'succeed'.

```

#### success
```
This is a placeholder definition for the term 'success'.

```

#### successful
```
This is a placeholder definition for the term 'successful'.

```

#### successively
```
This is a placeholder definition for the term 'successively'.

```

#### suggested
```
This is a placeholder definition for the term 'suggested'.

```

#### survey
```
This is a placeholder definition for the term 'survey'.

```

#### suﬀer
```
This is a placeholder definition for the term 'suﬀer'.

```

#### suﬀered
```
This is a placeholder definition for the term 'suﬀered'.

```

#### symbol
```
This is a placeholder definition for the term 'symbol'.

```

#### symbols
```
This is a placeholder definition for the term 'symbols'.

```

#### symptom
```
This is a placeholder definition for the term 'symptom'.

```

#### symptoms
```
This is a placeholder definition for the term 'symptoms'.

```

#### syntactic
```
This is a placeholder definition for the term 'syntactic'.

```

#### system
```
This is a placeholder definition for the term 'system'.

```

#### systems
```
This is a placeholder definition for the term 'systems'.

```

#### systems:
```
This is a placeholder definition for the term 'systems:'.

```

#### table
```
This is a placeholder definition for the term 'table'.

```

#### table”
```
This is a placeholder definition for the term 'table”'.

```

#### taken
```
This is a placeholder definition for the term 'taken'.

```

#### telligence
```
This is a placeholder definition for the term 'telligence'.

```

#### telligence”
```
This is a placeholder definition for the term 'telligence”'.

```

#### tentatively
```
This is a placeholder definition for the term 'tentatively'.

```

#### terms
```
This is a placeholder definition for the term 'terms'.

```

#### testing
```
This is a placeholder definition for the term 'testing'.

```

#### tests
```
This is a placeholder definition for the term 'tests'.

```

#### their
```
This is a placeholder definition for the term 'their'.

```

#### themselves
```
This is a placeholder definition for the term 'themselves'.

```

#### theorem
```
This is a placeholder definition for the term 'theorem'.

```

#### theory
```
This is a placeholder definition for the term 'theory'.

```

#### there
```
This is a placeholder definition for the term 'there'.

```

#### these
```
This is a placeholder definition for the term 'these'.

```

#### thesis
```
This is a placeholder definition for the term 'thesis'.

```

#### think
```
This is a placeholder definition for the term 'think'.

```

#### this
```
This is a placeholder definition for the term 'this'.

```

#### thoroughly
```
This is a placeholder definition for the term 'thoroughly'.

```

#### those
```
This is a placeholder definition for the term 'those'.

```

#### though
```
This is a placeholder definition for the term 'though'.

```

#### thought
```
This is a placeholder definition for the term 'thought'.

```

#### thoughts
```
This is a placeholder definition for the term 'thoughts'.

```

#### three
```
This is a placeholder definition for the term 'three'.

```

#### time
```
This is a placeholder definition for the term 'time'.

```

#### tions
```
This is a placeholder definition for the term 'tions'.

```

#### topic
```
This is a placeholder definition for the term 'topic'.

```

#### total
```
This is a placeholder definition for the term 'total'.

```

#### tragic
```
This is a placeholder definition for the term 'tragic'.

```

#### trans
```
This is a placeholder definition for the term 'trans'.

```

#### transforming
```
This is a placeholder definition for the term 'transforming'.

```

#### treats
```
This is a placeholder definition for the term 'treats'.

```

#### triple
```
This is a placeholder definition for the term 'triple'.

```

#### trying
```
This is a placeholder definition for the term 'trying'.

```

#### turned
```
This is a placeholder definition for the term 'turned'.

```

#### ultra-natural
```
This is a placeholder definition for the term 'ultra-natural'.

```

#### unable
```
This is a placeholder definition for the term 'unable'.

```

#### unchanged
```
This is a placeholder definition for the term 'unchanged'.

```

#### understand
```
This is a placeholder definition for the term 'understand'.

```

#### unenumer
```
This is a placeholder definition for the term 'unenumer'.

```

#### universal
```
This is a placeholder definition for the term 'universal'.

```

#### unless
```
This is a placeholder definition for the term 'unless'.

```

#### unpleasantly
```
This is a placeholder definition for the term 'unpleasantly'.

```

#### unsolved
```
This is a placeholder definition for the term 'unsolved'.

```

#### unsuccessful
```
This is a placeholder definition for the term 'unsuccessful'.

```

#### until
```
This is a placeholder definition for the term 'until'.

```

#### used
```
This is a placeholder definition for the term 'used'.

```

#### useful
```
This is a placeholder definition for the term 'useful'.

```

#### using
```
This is a placeholder definition for the term 'using'.

```

#### usual
```
This is a placeholder definition for the term 'usual'.

```

#### usually
```
This is a placeholder definition for the term 'usually'.

```

#### vague
```
This is a placeholder definition for the term 'vague'.

```

#### values
```
This is a placeholder definition for the term 'values'.

```

#### variables
```
This is a placeholder definition for the term 'variables'.

```

#### variety
```
This is a placeholder definition for the term 'variety'.

```

#### variously
```
This is a placeholder definition for the term 'variously'.

```

#### vious
```
This is a placeholder definition for the term 'vious'.

```

#### wanted
```
This is a placeholder definition for the term 'wanted'.

```

#### wants
```
This is a placeholder definition for the term 'wants'.

```

#### wasn’t
```
This is a placeholder definition for the term 'wasn’t'.

```

#### whenever
```
This is a placeholder definition for the term 'whenever'.

```

#### where
```
This is a placeholder definition for the term 'where'.

```

#### whether
```
This is a placeholder definition for the term 'whether'.

```

#### which
```
This is a placeholder definition for the term 'which'.

```

#### while
```
This is a placeholder definition for the term 'while'.

```

#### whole
```
This is a placeholder definition for the term 'whole'.

```

#### whose
```
This is a placeholder definition for the term 'whose'.

```

#### within
```
This is a placeholder definition for the term 'within'.

```

#### without
```
This is a placeholder definition for the term 'without'.

```

#### worked
```
This is a placeholder definition for the term 'worked'.

```

#### world
```
This is a placeholder definition for the term 'world'.

```

#### worth
```
This is a placeholder definition for the term 'worth'.

```

#### would
```
This is a placeholder definition for the term 'would'.

```

#### wouldn’t
```
This is a placeholder definition for the term 'wouldn’t'.

```

#### write
```
This is a placeholder definition for the term 'write'.

```

#### writing
```
This is a placeholder definition for the term 'writing'.

```

#### written
```
This is a placeholder definition for the term 'written'.

```

#### years
```
This is a placeholder definition for the term 'years'.

```

#### yielding
```
This is a placeholder definition for the term 'yielding'.

```

#### “knowledge
```
This is a placeholder definition for the term '“knowledge'.

```

#### “most
```
This is a placeholder definition for the term '“most'.

```

#### ∀xcs.ab(aspect2(x
```
This is a placeholder definition for the term '∀xcs.ab(aspect2(x'.

```

#### ∀xcs.color(x
```
This is a placeholder definition for the term '∀xcs.color(x'.

```

#### ∀xcs.¬ab(aspect4(x
```
This is a placeholder definition for the term '∀xcs.¬ab(aspect4(x'.

```

#### ∀xes.¬ab(aspect1(x
```
This is a placeholder definition for the term '∀xes.¬ab(aspect1(x'.

```

#### ∀xes.¬ab(aspect2(x
```
This is a placeholder definition for the term '∀xes.¬ab(aspect2(x'.

```

#### ∀xls.ab(aspect1(x
```
This is a placeholder definition for the term '∀xls.ab(aspect1(x'.

```

#### ∀xls.clear(top(x
```
This is a placeholder definition for the term '∀xls.clear(top(x'.

```

#### ∀xls.¬ab(aspect3(x
```
This is a placeholder definition for the term '∀xls.¬ab(aspect3(x'.

```

#### ∀xycs.loc(x
```
This is a placeholder definition for the term '∀xycs.loc(x'.

```

#### ∀xycs.y
```
This is a placeholder definition for the term '∀xycs.y'.

```

#### ∀xyls.color(y
```
This is a placeholder definition for the term '∀xyls.color(y'.

```

#### ∀xyls.y
```
This is a placeholder definition for the term '∀xyls.y'.

```

#### ﬁnding
```
This is a placeholder definition for the term 'ﬁnding'.

```

#### ﬁrst
```
This is a placeholder definition for the term 'ﬁrst'.

```

#### ﬁrst-order
```
This is a placeholder definition for the term 'ﬁrst-order'.

```

#### ﬂying
```
This is a placeholder definition for the term 'ﬂying'.

```

